class AccountSafeState {
}